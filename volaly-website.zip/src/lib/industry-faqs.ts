import type { IndustryPageData } from "./industries-data";

export type Faq = { q: string; a: string };

export const industryFaqs: Record<string, Faq[]> = {
  hotel: [
    {
      q: "Why isn't my hotel appearing when travellers search on Google or Google Maps?",
      a: "Incomplete or unclaimed Google Business Profile, inconsistent NAP data, wrong categories or low review velocity hide hotels from the Local Pack. Claim and verify the listing, standardise your name, address and phone across every directory, choose accurate lodging categories and generate a steady stream of recent reviews to rebuild your search presence.",
    },
    {
      q: "How can hotels reduce dependence on Booking.com and Agoda while staying visible?",
      a: "Optimise a fast mobile website with a real-time booking engine, list live rates on Google Hotel Ads and fully complete your Google Business Profile. Keep direct rates competitive so travellers have a clear reason to book with you. Strong owned channels shift meaningful volume to higher-margin direct bookings while OTAs remain useful for discovery.",
    },
    {
      q: "Do Google reviews actually influence direct bookings and ranking?",
      a: "Yes. Quantity, recency, average rating and owner responses are major Local Pack ranking factors. Hotels with a steady flow of recent reviews consistently outrank quieter competitors and convert more profile views into direct bookings. Set up an automated post-stay request, personalise the ask and reply to every single review within 24 hours.",
    },
    {
      q: "How can hotels convert more Google traffic into direct reservations instead of OTA clicks?",
      a: "Add a direct booking link to your Google Business Profile, keep rates competitive across all channels and ensure guests can complete a reservation in under three clicks on mobile. Use Google Hotel Ads for rate visibility. Removing those friction points turns Local Pack traffic and Maps searches into commission-free direct reservations.",
    },
    {
      q: "Why do so many hotel website visitors abandon the booking process?",
      a: "Slow page loads, multi-step checkout flows, missing live availability and weak calls-to-action are the main culprits. A streamlined booking path linked from your Business Profile, combined with AI-assisted availability checks that answer questions instantly, significantly reduces abandonment and increases conversion of the high-intent travellers already searching for your property.",
    },
    {
      q: "Why doesn't my hotel get recommended in ChatGPT or other AI travel answers?",
      a: "AI systems pull from clear entity data, consistent descriptions, recent reviews and structured amenity lists. If your profile is incomplete or key details are buried in images rather than readable text, AI tools simply cannot surface your property. Strengthen profile completeness and use plain text for services, facilities and unique selling points.",
    },
    {
      q: "Can AI agents answer guest questions and complete direct bookings automatically?",
      a: "AI agents handle availability enquiries, rate questions, amenity details and booking policies across web chat, WhatsApp and email around the clock, then guide guests directly to a reservation. They capture after-hours demand that would otherwise be lost, reduce front-desk call volume significantly and escalate complex requests to staff with full conversation context.",
    },
    {
      q: "How can hotels capture guest data after a stay and use it for rebooking?",
      a: "Connecting your booking engine, review requests and guest messaging into a unified CRM enables automated post-stay messages, timely review nudges and targeted rebooking offers tailored to each guest's previous stay. This transforms one-time visitors into repeat guests, improves lifetime value and gives you a direct communication channel without OTA dependency.",
    },
    {
      q: "How do hotels increase repeat stays without relying on deep discounts?",
      a: "Timely review requests, personalised post-stay messages and exclusive member-rate offers consistently outperform deep discounting as loyalty drivers. Automated follow-up sequences keep your property top-of-mind between trips, increase revisit frequency and allow you to reward loyal guests with early access, upgrades or added value rather than racing rivals to the bottom on price.",
    },
    {
      q: "What return can independent hotels realistically expect from AI visibility and automation tools?",
      a: "Entry-level tools typically start at $99–$300 per month. Return comes from higher direct-booking conversion, recovered after-hours enquiries that previously went unanswered and lower OTA commissions on volume shifted to direct channels. Properties that remove booking friction and automate guest communication consistently see full payback within 60–90 days of going live.",
    },
  ],

  restaurant: [
    {
      q: "Why isn't my restaurant showing up on Google Maps when people search nearby?",
      a: "Incomplete or unverified Google Business Profile, wrong primary category, inconsistent NAP data or low recent review volume prevent appearance in the Local Pack. Claim and verify your listing, select the most specific cuisine category, fill in every field including menu and hours and build a steady stream of recent reviews to restore visibility.",
    },
    {
      q: "How can restaurants get more table reservations directly from Google and Maps?",
      a: "Add a direct reservation link to your Google Business Profile, keep hours and menu accurate in searchable text rather than images and post current specials regularly. Ensure your website completes a booking in under three clicks on mobile. Strong Local Pack placement plus zero-friction booking converts searches directly into confirmed table reservations.",
    },
    {
      q: "Do Google reviews really decide whether people choose my restaurant?",
      a: "Yes. Volume, recency, average rating and owner responses heavily influence both Local Pack ranking and guest decisions. Restaurants with a steady flow of recent reviews consistently outperform quieter competitors in visibility and conversion. Request reviews shortly after positive visits, personalise the ask and reply to every review within 24 hours.",
    },
    {
      q: "Why do so many potential diners look at my profile or website and never book?",
      a: "Multi-step forms, missing real-time availability, slow mobile load times or unclear calls-to-action cause visitors to abandon before booking. A frictionless reservation path linked directly from your Business Profile, combined with AI-powered availability checks that answer questions instantly, converts more of the high-intent Local Pack traffic you already receive into confirmed reservations.",
    },
    {
      q: "How can restaurants handle more walk-ins and last-minute reservations without extra staff?",
      a: "Real-time availability tools and AI agents that handle wait-time and last-minute booking queries across messaging channels — web chat, WhatsApp, Instagram — free your floor staff while capturing demand that would otherwise be lost to a competitor. They can confirm tables, add names to the waiting list and escalate special requests instantly.",
    },
    {
      q: "Why doesn't my restaurant appear in ChatGPT, Gemini or Perplexity food recommendations?",
      a: "AI systems pull from clear entity data, consistent descriptions, recent reviews and structured menu information in readable text. If your profile is incomplete or your menu is locked inside image files, AI tools cannot recommend your restaurant. Strengthen profile completeness and use plain text for cuisines, popular dishes and dining experience details.",
    },
    {
      q: "Can AI chatbots take reservations and answer menu questions 24/7?",
      a: "Yes. AI agents handle menu and allergen questions, opening hours, wait times and availability across web chat, WhatsApp and Instagram around the clock, then guide guests to book a table. They capture after-hours demand, free front-of-house staff during busy service and escalate special requests or complaints with full conversation context.",
    },
    {
      q: "How can restaurants capture guest data after a visit and turn one-time diners into regulars?",
      a: "Connecting your reservation system, review requests and guest messaging into a unified CRM enables automated thank-you messages, timely review nudges and targeted offers tied to each guest's visit history. This turns first-time diners into regulars, increases visit frequency and gives you a direct channel to guests without relying on aggregators.",
    },
    {
      q: "How do restaurants increase repeat visits without constant discounting?",
      a: "Consistent service quality, timely review requests, personalised follow-up messages and exclusive regular-guest offers consistently outperform constant discounting as drivers of loyalty. Automated sequences keep your restaurant top-of-mind between visits, reward returning guests with early access to new menus or events and increase frequency at higher margins than promotional pricing alone.",
    },
    {
      q: "What does AI automation and visibility typically cost a restaurant and what payback is realistic?",
      a: "Entry-level tools usually start at $99–$300 per month. Return comes from higher reservation conversion, recovered after-hours bookings that previously went unanswered and improved repeat-visit frequency from automated guest follow-up. Restaurants that remove booking friction and start building first-party guest data early typically see full payback within 60–90 days of going live.",
    },
  ],

  bar: [
    {
      q: "Why isn't my bar appearing in local 'bars near me' or 'happy hour' searches?",
      a: "Unverified or incomplete Google Business Profile, overly generic categories, outdated trading hours or low review activity all suppress Local Pack visibility. Claim and verify the listing, choose specific sub-categories such as Cocktail Bar, Sports Bar or Wine Bar, fill in every field including event hours and build a consistent flow of recent reviews.",
    },
    {
      q: "How can bars get more event and VIP table reservations from Google?",
      a: "Add a reservation or VIP table enquiry link to your Google Business Profile, keep special event hours current and post upcoming nights and promotions regularly. Make sure the booking path is clear on mobile. Strong Local Pack placement combined with frictionless table booking converts weekend searches into confirmed VIP reservations.",
    },
    {
      q: "Do Google reviews affect whether people choose my bar over the one next door?",
      a: "Yes. Volume, recency and owner responses are major trust and ranking factors that separate busy venues from invisible ones. Bars with a consistent stream of recent reviews outperform quieter competitors in both Local Pack position and conversion. Ask for a review at the end of a good night and reply to every one.",
    },
    {
      q: "Why do many people check my bar online but never reserve or show up?",
      a: "Missing real-time table availability, unclear event information or weak next-step prompts cause visitors to check and leave. A fast reservation path, accurate event listings and an AI agent that can answer capacity and availability questions converts more casual online interest into confirmed bookings and stronger table revenue night after night.",
    },
    {
      q: "How can bars capture late-night and after-hours enquiries that currently go unanswered?",
      a: "AI agents that handle trading hours, event line-ups, wait times and table reservations across messaging channels — web chat, WhatsApp, Instagram DMs — capture demand that arrives after the door team is busy or the venue is closed. They reduce missed opportunities, free staff during peak periods and escalate VIP requests with full context.",
    },
    {
      q: "Why doesn't my bar get mentioned in AI recommendations for nights out?",
      a: "AI systems prioritise clear entity data, recent reviews and structured information such as event types, music genres and typical crowd details. Incomplete profiles or details buried inside images create discovery gaps that prevent AI tools from recommending your venue. Strengthen your profile with readable text and consistent descriptions of each night you run.",
    },
    {
      q: "Can AI agents handle event enquiries, wait times and table reservations automatically?",
      a: "Yes. AI agents answer event queries, trading hours, wait times and table availability around the clock across web chat, WhatsApp and Instagram, then guide guests to reserve. They capture after-hours enquiries, free your front-of-house staff during peak periods and escalate complex VIP or group bookings with the full conversation intact.",
    },
    {
      q: "How can bars collect guest data from reservations and events for future marketing?",
      a: "Connecting reservations and guest messaging into a unified CRM enables automated post-visit follow-up, timely review requests and targeted event invitations based on each guest's visit history. This turns one-off visitors into regulars, builds a first-party contact list you own and allows you to promote upcoming nights without relying on paid social advertising.",
    },
    {
      q: "How do bars turn one-time visitors into regulars without heavy drink specials?",
      a: "Consistent atmosphere, timely post-visit follow-up and exclusive early-access invitations to upcoming events or VIP nights consistently outperform drink specials as loyalty tools. Automated sequences keep your venue top-of-mind between visits, reward regular guests with access or perks they genuinely value and increase visit frequency at significantly higher margins than constant promotional discounting.",
    },
    {
      q: "What return can independent bars expect from AI visibility and automation?",
      a: "Entry-level tools typically start at $99–$250 per month. Return comes from higher table reservation conversion, recovered after-hours enquiries that would otherwise go unanswered and improved repeat-visit frequency driven by automated guest follow-up. Venues that reduce booking friction and begin capturing first-party guest data early typically see full payback within 60–90 days.",
    },
  ],

  gym: [
    {
      q: "Why isn't my gym showing up when people search 'gym near me'?",
      a: "Unverified profile, wrong categories, incomplete service listings or low review velocity all prevent your gym from appearing in the Local Pack. Claim and verify your Google Business Profile, choose specific fitness categories, list every class and service in searchable text and build a consistent flow of recent member reviews to restore visibility.",
    },
    {
      q: "How can gyms generate more trial membership leads from Google and Maps?",
      a: "Add a direct trial booking link to your Google Business Profile, list your class schedule and membership tiers in plain text and ensure your website completes a booking in under three clicks on mobile. Strong Local Pack placement puts your gym in front of high-intent searchers at the exact moment they decide to start.",
    },
    {
      q: "Do Google reviews influence whether someone books a trial at my gym?",
      a: "Yes. Volume, recency and owner responses are major trust and ranking signals. Gyms with a consistent flow of recent reviews convert more profile views into trial bookings and rank higher in Local Pack results. Ask for a review after every session or class, personalise the request and reply to every response you receive.",
    },
    {
      q: "Why do so many people start a trial but never convert to full membership?",
      a: "Slow or inconsistent follow-up in the days after a trial is the primary reason. Prospects evaluate multiple options simultaneously and choose whoever responds fastest with the most relevant information. Automated nurture sequences sending class previews, testimonials and a clear membership offer within 48 hours of the trial significantly improve conversion rates.",
    },
    {
      q: "How can gyms reduce no-shows for trials and class bookings?",
      a: "Automated reminders sent 24 hours and one hour before each session, easy one-click rescheduling links and clear confirmation messages with directions and what to bring all reduce no-shows substantially. Protecting class capacity protects instructor margins and allows you to offer released spots to members waiting on the waitlist instead.",
    },
    {
      q: "Why doesn't my gym appear in ChatGPT or AI fitness recommendations?",
      a: "AI systems prioritise clear entity data, recent reviews and structured class and service information in readable text. If your timetable is only available as a PDF or image, AI tools cannot surface your gym when someone asks for local fitness recommendations. Strengthen your profile with plain-text class listings, specialties and member testimonials.",
    },
    {
      q: "Can AI chatbots answer class schedules, membership questions and book trials automatically?",
      a: "Yes. AI agents handle class schedules, membership pricing, personal training options and trial availability across web chat, WhatsApp and Instagram around the clock, then guide prospects to book. They capture late-night and weekend interest when the front desk is closed, free reception staff and escalate complex membership questions with full context.",
    },
    {
      q: "How can gyms capture trial data and follow up effectively until conversion?",
      a: "Connecting trial bookings and guest messaging into a unified CRM enables automated follow-up sequences — session highlights, member testimonials, time-limited membership offers — that move prospects from interested to committed. Tracking each prospect's touchpoints lets you personalise timing and content so the right offer arrives at exactly the right moment to convert.",
    },
    {
      q: "How do gyms improve member retention and reduce monthly churn?",
      a: "Timely engagement surveys after the first month, personalised class recommendations based on attendance patterns and automated re-engagement messages after a one-week absence all keep members active longer. Pair these with exclusive loyalty perks for members past six months and you improve both satisfaction scores and monthly retention rates significantly over time.",
    },
    {
      q: "What does AI automation and visibility typically cost a gym and what ROI is realistic?",
      a: "Entry-level tools usually start at $99–$300 per month. Return comes from higher trial-to-membership conversion, reduced no-show rates and lower monthly churn through better-timed automated re-engagement. Gyms that implement AI follow-up alongside Google profile optimisation typically see full payback within 60–90 days, with compounding gains as the retained member base grows.",
    },
  ],

  dentist: [
    {
      q: "Why isn't my dental practice appearing in 'dentist near me' searches?",
      a: "Unclaimed or incomplete Google Business Profile, incorrect categories or low review velocity hide practices from the Local Pack. Claim and verify your listing, choose dental-specific categories — General Dentist, Cosmetic Dentist, Orthodontist — fill every field including services and opening hours in plain text and build a steady flow of recent patient reviews.",
    },
    {
      q: "How can dental practices get more new-patient appointments from Google?",
      a: "Add a direct appointment link to your Google Business Profile, list every treatment you offer in searchable text and ensure your website books an appointment in under three clicks on mobile. Strong Local Pack placement puts your practice in front of high-intent patients at the exact moment they decide to seek dental care.",
    },
    {
      q: "Do Google reviews decide whether a patient chooses my practice?",
      a: "Yes. Volume, recency and owner responses are major trust and ranking signals in healthcare. Patients under pain or anxiety need confidence before choosing a provider. Practices with a steady flow of recent reviews consistently attract more new patients. Request a review at checkout, personalise the message and reply to every one you receive.",
    },
    {
      q: "Why do many potential patients look at my profile and never book an appointment?",
      a: "Multi-step booking forms, missing real-time appointment availability or slow mobile pages cause patients to abandon and try the next practice. A frictionless appointment path linked directly from your Business Profile, combined with instant booking confirmation messages, converts more of the motivated searchers already finding your listing into confirmed first-time patient appointments.",
    },
    {
      q: "How can dental practices reduce no-shows and last-minute cancellations?",
      a: "Automated reminders sent 48 hours and two hours before each appointment, one-click rescheduling links and clear pre-appointment instructions all reduce no-shows substantially. Protecting chair time from avoidable gaps is one of the highest-leverage actions an independent practice can take to improve daily revenue without needing to acquire a single additional new patient.",
    },
    {
      q: "Why doesn't my practice get recommended in ChatGPT or AI health answers?",
      a: "AI systems pull from clear entity data, recent patient reviews and structured service information in readable text. If your treatments are only listed in PDFs or images, or your Business Profile is sparse, AI tools cannot recommend your practice confidently. Strengthen every field with plain-text service descriptions, team credentials and clear patient outcome information.",
    },
    {
      q: "Can AI agents answer common patient questions and book appointments 24/7?",
      a: "Yes. AI agents handle treatment overviews, insurance questions, opening hours and appointment availability across web chat, WhatsApp and phone around the clock, then guide patients to book. They capture after-hours enquiries from patients in discomfort, free reception staff during busy periods and escalate clinical or emergency questions to a qualified team member.",
    },
    {
      q: "How can dental practices capture patient data and run effective recall campaigns?",
      a: "Connecting your appointment system and patient messaging into a unified CRM enables automated six-month recall messages, post-treatment follow-up surveys and targeted promotions for whitening or hygiene appointments. This keeps patients attending on schedule, improves treatment plan acceptance rates and significantly increases lifetime value per patient without requiring additional external marketing spend.",
    },
    {
      q: "How do dental practices turn new patients into long-term, high-value patients?",
      a: "Consistent care quality, timely recall reminders and personalised follow-up after each treatment build trust and attendance far more effectively than one-off new-patient discounts. Patients who feel valued and remembered attend recall appointments, accept higher-value treatment plans and refer family and friends — all of which compound into measurable long-term revenue growth.",
    },
    {
      q: "What return can independent dental practices expect from AI visibility and automation?",
      a: "Entry-level tools typically start at $99–$350 per month. Return comes from higher new-patient conversion, reduced no-show rates and improved recall attendance through automated follow-up. Practices that optimise their Google profile and automate patient communication consistently see full payback within 60–90 days, with increasing gains as the retained patient base grows.",
    },
  ],

  "medical-beauty": [
    {
      q: "Why isn't my medical clinic showing up in local patient searches?",
      a: "Unverified or incomplete Google Business Profile, overly generic categories or low review velocity hide clinics from local patient searches. Claim and verify your listing, choose precise treatment categories — Aesthetic Clinic, Skin Clinic, Laser Treatment — fill every field with plain-text service descriptions and build a consistent flow of recent patient reviews.",
    },
    {
      q: "How can medical clinics get more appointment bookings from Google Maps?",
      a: "Add a direct booking link to your Google Business Profile, list every treatment in searchable plain text with clear outcome descriptions and ensure your website completes a booking in under three clicks on mobile. Strong Local Pack placement converts high-intent searches for specific procedures directly into confirmed consultation or treatment appointments.",
    },
    {
      q: "Do Google reviews influence whether patients choose my clinic?",
      a: "Yes. Volume, recency and owner responses are major trust signals in elective healthcare where patients invest both money and confidence in results. Clinics with a steady flow of recent reviews consistently attract more new consultations. Set up a post-treatment review request, personalise it to the procedure and reply to every response.",
    },
    {
      q: "Why do so many potential patients visit my profile or website and leave without booking?",
      a: "Multi-step booking forms, missing real-time availability or dense clinical language that fails to answer the visitor's core question all cause drop-off. A frictionless consultation path linked directly from your Business Profile, with clear outcome-focused service descriptions and instant confirmation messages, converts significantly more motivated searchers into confirmed first-visit appointments.",
    },
    {
      q: "How can clinics reduce appointment no-shows and cancellations?",
      a: "Automated reminders sent 48 hours and two hours before each appointment, easy one-click rescheduling and clear pre-procedure preparation instructions all substantially reduce no-shows. Protecting clinic slots from avoidable gaps — especially for longer, high-revenue procedures — is one of the single highest-leverage improvements an aesthetic clinic can make to its daily revenue.",
    },
    {
      q: "Why doesn't my clinic appear in ChatGPT or AI medical recommendations?",
      a: "AI systems prioritise clear entity data, recent reviews and structured treatment information in readable text. Sparse profiles, image-based menus or vague descriptions that do not match what patients actually search for prevent AI tools from recommending your clinic. Fill every field with specific, plain-text treatment descriptions and clear, searchable outcome information.",
    },
    {
      q: "Can AI agents handle patient enquiries and book appointments automatically?",
      a: "Yes. AI agents handle procedure overviews, pricing ranges, recovery times, practitioner credentials and appointment availability across web chat, WhatsApp and email around the clock, then guide patients to book a consultation. They capture after-hours interest, free clinic reception staff during busy treatment days and escalate clinical suitability questions to qualified practitioners.",
    },
    {
      q: "How can medical clinics capture patient data for effective recall and follow-up?",
      a: "Connecting your appointment system and patient messaging into a unified CRM enables automated follow-up surveys after each treatment, recall prompts for maintenance sessions and targeted promotions for complementary procedures. This improves retention, increases average patient lifetime spend and provides the structured data you need to market effectively to your best patient profiles.",
    },
    {
      q: "How do clinics improve patient retention and lifetime value?",
      a: "Consistent treatment results, timely follow-up surveys, personalised maintenance reminders and exclusive early-access offers for new procedures keep patients loyal and spending far more effectively than one-off introductory discounts. Patients who trust their clinic refer friends and family — a compounding revenue source that costs significantly less than acquiring cold new leads.",
    },
    {
      q: "What does AI automation and visibility typically cost a medical clinic and what payback is realistic?",
      a: "Entry-level tools typically start at $99–$350 per month. Return comes from higher consultation conversion, meaningfully reduced no-show rates and stronger treatment retention driven by automated patient follow-up. Aesthetic clinics that optimise their Google presence and automate communication consistently see full payback within 60–90 days, with compounding returns as patients book additional procedures.",
    },
  ],

  "real-estate": [
    {
      q: "Why isn't my real estate agent profile appearing in local searches?",
      a: "Unclaimed or incomplete Google Business Profile, wrong categories or low review velocity typically hide agents from local searches. Claim and verify an individual agent profile, choose agent-specific categories, list your service areas and specialties in plain text, include a professional photo and build a consistent stream of recent client reviews to restore visibility.",
    },
    {
      q: "How can real estate agents generate more qualified seller and buyer leads from Google?",
      a: "Add a clear contact or valuation link to your Google Business Profile, list service areas and property specialties in plain text, post recent sale highlights and ensure your website responds to enquiries instantly. Strong Local Pack placement puts your profile in front of motivated sellers and buyers at the exact moment of intent.",
    },
    {
      q: "Do Google reviews affect whether clients choose me over other agents?",
      a: "Yes. Volume, recency and owner responses are significant trust signals in a high-stakes decision where clients evaluate every available signal before committing. Agents with a consistent flow of recent reviews win more mandates and referrals. Request a review after every closing, personalise the message to the client and reply to every one.",
    },
    {
      q: "Why do so many enquiries go cold after the first contact?",
      a: "Slow initial response and lack of systematic nurturing are the primary causes. Buyers and sellers contact multiple agents simultaneously and commit to whoever responds first with relevant information. AI-assisted qualification that replies within minutes of an enquiry and automated follow-up sequences that maintain contact over weeks keep significantly more leads engaged and progressing.",
    },
    {
      q: "How can agents respond faster and qualify leads without living on their phone?",
      a: "AI agents that answer initial area questions, price guidance and property availability 24/7 across web chat, WhatsApp and email qualify leads instantly and schedule viewings without requiring the agent to be available. This frees you to focus on high-value appointments while ensuring every inbound enquiry receives a fast, professional first response.",
    },
    {
      q: "Why doesn't my profile or listings appear in ChatGPT or AI property recommendations?",
      a: "AI systems prioritise clear entity data, consistent reviews and structured information about service areas, property types and transaction history. Sparse or generic profiles that do not specify the markets you serve create gaps that prevent AI tools from surfacing your name when buyers and sellers ask for local agent recommendations in your area.",
    },
    {
      q: "Can AI agents answer initial lead questions and schedule property viewings automatically?",
      a: "Yes. AI agents handle area and price questions, schedule viewings and qualify buyers and sellers across web, WhatsApp and email around the clock, then escalate high-intent leads to you with the full conversation history. They ensure no enquiry waits more than a few minutes for a response regardless of time or day.",
    },
    {
      q: "How can real estate agents capture and nurture leads that are not ready to buy or sell yet?",
      a: "A CRM with automated follow-up sequences sends relevant market updates, new listing alerts and check-in messages on a schedule tailored to each lead's timeline — whether they plan to act in six weeks or six months. This keeps longer-term leads warm and positions you as the obvious choice when they are ready to move.",
    },
    {
      q: "How do agents turn closed clients into consistent referral sources?",
      a: "Timely post-closing thank-you messages, regular market update newsletters and exclusive off-market previews keep past clients engaged and generate ongoing referrals far more effectively than generic seasonal cards. Automated touchpoint sequences ensure no former client goes more than 90 days without relevant, personalised contact — turning closed deals into a compounding referral pipeline.",
    },
    {
      q: "What return can individual agents realistically expect from AI visibility and automation tools?",
      a: "Entry-level tools typically start at $99–$300 per month. Return comes from faster lead response times, higher conversion of enquiries into viewings and improved referral frequency through automated client follow-up. Agents who implement AI qualification alongside Google profile optimisation consistently see full payback within 60–90 days and compounding gains thereafter.",
    },
  ],

  "visa-agency": [
    {
      q: "Why isn't my visa agency appearing when people search for consultants locally?",
      a: "Unverified or incomplete Google Business Profile, overly broad categories or low review velocity hide agencies from high-intent local searches. Claim and verify your listing, choose precise service categories, list every visa type you handle in plain searchable text and build a consistent flow of client reviews to restore Local Pack visibility.",
    },
    {
      q: "How can visa agencies get more consultation bookings from Google?",
      a: "Add a direct consultation booking link to your Google Business Profile, list the specific visa categories and destination countries you handle in plain text and ensure your website converts an enquiry into a booked appointment in under three steps. Local Pack placement converts urgent, high-intent searches into confirmed paid consultation bookings.",
    },
    {
      q: "Do Google reviews influence whether clients choose my agency?",
      a: "Yes. In a high-stakes, trust-sensitive service, reviews are the primary signal prospective clients use to choose between agencies. Volume, recency and how you respond all influence both ranking and conversion. Request a review after every successful case outcome, make the process easy for the client and reply personally to every response.",
    },
    {
      q: "Why do many potential clients enquire but never book a paid consultation?",
      a: "Slow initial response and unclear next steps are the main causes of drop-off. Prospective clients researching immigration options evaluate multiple agencies simultaneously and choose whoever provides the clearest guidance fastest. AI-assisted instant responses that confirm receipt, outline the process and invite a consultation appointment convert significantly more inbound enquiries into booked sessions.",
    },
    {
      q: "How can visa agencies qualify leads and documents faster without extra staff?",
      a: "AI agents that handle initial process overviews, document requirement checklists and basic eligibility questions across web chat, WhatsApp and email free your consultants to focus on complex case work and billable consultation time. They accelerate the qualification pipeline and ensure every enquiry receives a professional, informative first response within seconds of arriving.",
    },
    {
      q: "Why doesn't my agency appear in ChatGPT or AI immigration recommendations?",
      a: "AI systems prioritise clear entity data, recent reviews and structured service information. Agencies that list specific visa categories, destination countries and typical processing timelines in plain text are far more likely to be recommended than those with sparse or vague profiles. Strengthen every field with plain-text descriptions of the cases you handle best.",
    },
    {
      q: "Can AI agents answer process questions and book consultations automatically?",
      a: "Yes. AI agents handle process overview questions, document requirements and consultation availability 24/7 across web chat, WhatsApp and email, then guide clients to book a paid session. They capture after-hours enquiries from clients in urgent situations, free consultants during busy periods and escalate complex or sensitive cases with full conversation context.",
    },
    {
      q: "How can visa agencies capture client data and manage follow-up throughout the case?",
      a: "A unified CRM with automated milestone update messages keeps clients informed at every stage of their application without manual chasing. It also enables automated document reminder sequences, referral requests after successful outcomes and case anniversary messages — all of which build long-term loyalty and generate referrals from satisfied former clients.",
    },
    {
      q: "How do visa agencies turn completed cases into referrals and repeat business?",
      a: "Timely outcome follow-up messages, referral requests paired with a review ask and exclusive updates about new visa pathways or policy changes keep former clients engaged and actively referring family and friends. In immigration consulting, word-of-mouth from successful cases is the highest-converting and lowest-cost source of new high-value client enquiries.",
    },
    {
      q: "What does AI automation and visibility typically cost a visa agency and what ROI is realistic?",
      a: "Entry-level tools usually start at $99–$300 per month. Return comes from higher paid-consultation conversion, faster lead qualification and improved referral frequency through automated follow-up. Agencies that implement AI-assisted responses and profile optimisation simultaneously typically see full payback within 60–90 days and compounding gains as the referral base continues to grow.",
    },
  ],

  "car-rental": [
    {
      q: "Why isn't my car rental company showing up in local or airport searches?",
      a: "Unverified or incomplete Google Business Profile, overly broad categories or low review velocity hide rental companies from local and airport-intent searches. Claim and verify a profile for each physical location, choose specific vehicle category types, fill every field including fleet details in plain text and build a consistent flow of recent client reviews.",
    },
    {
      q: "How can car rental companies get more direct bookings from Google instead of marketplaces?",
      a: "Add a direct online booking link to your Google Business Profile, list vehicle classes, passenger capacities and included features in plain text and ensure your website completes a reservation in under three clicks on mobile. Strong Local Pack placement converts high-intent pre-travel and airport searches directly into confirmed same-day reservations.",
    },
    {
      q: "Do Google reviews affect whether travellers choose my fleet?",
      a: "Yes. Volume, recency and owner responses are major trust factors for travellers making time-sensitive decisions. Rental companies with a consistent flow of recent reviews outrank quieter competitors and convert more profile views into confirmed bookings. Request a review at vehicle return, make the process effortless for the customer and reply to every response.",
    },
    {
      q: "Why do so many potential renters check availability and then leave?",
      a: "Travellers checking vehicle availability expect an instant answer. Missing real-time fleet data, multi-step quote forms or redirects to third-party portals all cause drop-off to a competitor with a faster booking path. Integrating live inventory directly into the website and Business Profile removes friction and captures more of that high-intent search traffic.",
    },
    {
      q: "How can car rental companies show real-time fleet availability and reduce booking friction?",
      a: "Connecting your fleet management system to a real-time booking engine and AI agent creates a single source of truth for availability that customers can query instantly. Accurate live inventory prevents double bookings, reduces inbound availability calls and converts more browsing sessions into confirmed reservations by answering the availability question before customers even ask.",
    },
    {
      q: "Why doesn't my company appear in ChatGPT or AI travel recommendations?",
      a: "AI systems prioritise clear entity data, recent reviews and structured fleet information such as vehicle categories, fuel policy, pickup locations and included extras. Incomplete profiles or fleet details buried in PDFs create discovery gaps. Strengthen every field with plain-text vehicle descriptions so AI tools can recommend your fleet with confidence.",
    },
    {
      q: "Can AI agents answer vehicle questions and complete reservations automatically?",
      a: "Yes. AI agents handle vehicle availability, pricing, pickup location details, insurance options and after-hours enquiries across web chat, WhatsApp and email around the clock, then guide customers to complete a reservation. They capture demand outside staffed hours, reduce inbound phone volume and escalate complex or modification requests with full conversation context.",
    },
    {
      q: "How can car rental companies capture customer data after a rental for rebooking?",
      a: "Connecting your booking system and customer messaging into a unified CRM enables automated return thank-you messages, timely review requests and targeted rebooking offers timed around each customer's upcoming travel patterns. This turns one-time renters into repeat customers and gives you a direct marketing channel completely independent of aggregator platforms.",
    },
    {
      q: "How do car rental companies increase repeat rentals without constant discounting?",
      a: "Consistent vehicle condition, transparent pricing, timely post-rental follow-up and exclusive loyalty rates for returning customers all outperform blanket discounting as retention drivers. Automated sequences that deliver relevant rebooking offers timed around each customer's next anticipated travel dates increase repeat rental frequency at meaningfully higher margins than competing on public promotional pricing.",
    },
    {
      q: "What return can independent car rental operators expect from AI visibility and automation?",
      a: "Entry-level tools typically start at $99–$300 per month. Return comes from higher direct booking conversion, recovered after-hours enquiries that previously went unanswered and improved repeat-rental frequency through targeted automated follow-up. Independent operators who remove booking friction and optimise their Google presence simultaneously typically see full payback within 60–90 days.",
    },
  ],

  "social-media-influencer": [
    {
      q: "Why aren't brands finding or contacting my creator profile?",
      a: "Unclear niche, missing or buried contact details, inconsistent posting patterns or low engagement-to-follower ratios all reduce brand discoverability. Tighten your content niche to a specific topic and audience segment, add a clear business contact method to every profile, build a professional media kit and focus on driving meaningful engagement per post.",
    },
    {
      q: "How can influencers get more inbound brand deals and paid collaborations?",
      a: "Maintain clear, consistent niche positioning across every platform, keep engagement metrics strong and visible in your media kit and make it effortless for brand managers to contact you within seconds of landing on your profile. Brands evaluate content-audience fit, engagement depth and professional responsiveness far more heavily than raw follower count alone.",
    },
    {
      q: "Do engagement rate and audience quality matter more than follower count for brand deals?",
      a: "Yes. Brand managers evaluate comments, saves, shares, story replies and watch-through rate as primary performance proxies. Creators with strong, authentic engagement consistently attract more inbound deals, command higher rates and retain brand partners across multiple campaigns. Chasing follower numbers at the expense of community quality is one of the most common and costly mistakes.",
    },
    {
      q: "Why do many brand enquiries go cold after the first message?",
      a: "Slow replies signal low professionalism to brand managers evaluating multiple creators simultaneously. If an enquiry sits unanswered for more than a few hours, the opportunity often moves to a competitor. AI-assisted instant acknowledgement, a clear brief intake form and a structured follow-up process keep significantly more inbound brand opportunities alive.",
    },
    {
      q: "How can creators respond faster and qualify brand deals without constant DMing?",
      a: "AI tools that send an instant acknowledgement with a brief intake questionnaire, then route completed responses to your inbox, free you from monitoring every DM while ensuring no serious brand enquiry is lost. They qualify interest level, capture campaign details and escalate high-value or time-sensitive opportunities immediately to your attention.",
    },
    {
      q: "Why doesn't my content surface in ChatGPT or AI creator recommendations?",
      a: "AI systems surface creators based on niche clarity, content consistency, audience demographic signals and web presence. Vague or cross-niche positioning, sparse platform bios or no dedicated website make it difficult for AI tools to categorise and recommend you. Strengthen niche-specific keywords in bios, captions and any web properties you own.",
    },
    {
      q: "Can AI tools help handle brand enquiries and audience questions automatically?",
      a: "Yes. AI agents answer common collaboration questions — partnership terms, audience demographics, content timelines — across DMs, email and web chat around the clock, then route serious brand enquiries to you with the full conversation context. They maintain professional response times while you are creating, filming or simply offline and unavailable.",
    },
    {
      q: "How can influencers capture and organise brand leads and collaboration history?",
      a: "A simple CRM that logs every inbound enquiry, tracks follow-up dates, stores campaign briefs and records collaboration outcomes prevents opportunities from slipping through your DMs. It also provides the structured performance data you need to demonstrate ROI to existing partners and justify rate increases when renewing or pitching new campaigns.",
    },
    {
      q: "How do creators turn one-time brand deals into ongoing partnerships and residual income?",
      a: "Proactive performance reporting after each campaign, consistent relationship check-ins and exclusive partnership offers for repeat collaborators convert single activations into ongoing retainers and affiliate arrangements. Creators who treat brand relationships with the same professionalism as client accounts generate compounding residual income rather than chasing new logos with every content cycle.",
    },
    {
      q: "What does AI automation and visibility typically cost a creator and what return is realistic?",
      a: "Entry-level tools usually start at $49–$200 per month. Return comes from faster brand response, higher deal conversion from qualified inbound enquiries and improved residual income from better-managed affiliate and retainer relationships. Most full-time creators who commit to the system see full payback within 30–60 days as enquiry-to-deal conversion improves.",
    },
  ],
};

/** Related industry slugs for internal linking */
export const relatedIndustries: Record<string, string[]> = {
  hotel: ["restaurant", "bar", "car-rental"],
  restaurant: ["hotel", "bar", "gym"],
  bar: ["restaurant", "hotel", "social-media-influencer"],
  gym: ["dentist", "medical-beauty"],
  dentist: ["medical-beauty", "gym"],
  "medical-beauty": ["dentist", "gym"],
  "real-estate": ["visa-agency"],
  "visa-agency": ["real-estate", "medical-beauty"],
  "car-rental": ["hotel", "restaurant"],
  "social-media-influencer": ["real-estate", "bar"],
};
